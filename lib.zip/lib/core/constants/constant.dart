import 'package:flutter/material.dart';

const kwidth = SizedBox(
  width: 10,
);
const kheight = SizedBox(
  height: 10,
);
const kheight20 = SizedBox(
  height: 20,
);
// border radius
BorderRadius kRadius20 = BorderRadius.circular(20);
final BorderRadius kRadius30 = BorderRadius.circular(30);

// image
const kMainimage =
    "https://pbs.twimg.com/media/Ew2fEI3WEAYRUYr?format=jpg&name=4096x4096";

// text style
TextStyle kHomeTitleText = const TextStyle(
  fontSize: 14,
  fontWeight: FontWeight.bold,
);
const commingsoonImage =
    "https://pbs.twimg.com/profile_images/1610347012612055042/3GXaEMJC_400x400.png";
