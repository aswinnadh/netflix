import 'package:flutter/material.dart';

const backgroundcolor = Colors.black;
const kwhiteColor = Colors.white;
const kbuttonColorBlue = Color.fromARGB(255, 64, 42, 233);
const kbuttonColorWhite = Colors.white;
const kblackColor = Colors.black;
